Events.on(ClientLoadEvent, () => {
    // Build the HUD table on top of Mindustry UI
    const hud = new Table();
    hud.bottom().left(); // Positions HUD at bottom-left corner

    // Title label
    hud.add("WEAPON HUD").color(Color.gold).pad(4).row();

    // Helper function to attach weapons
    function attachWeapon(unitTypeStr, index = 0) {
        let unit = Vars.player.unit();
        if (!unit) return;
        
        let type = Vars.content.getByName(ContentType.unit, unitTypeStr);
        if (type && type.weapons.size > index) {
            let newWeapon = type.weapons.get(index).clone();
            unit.mounts.add(new WeaponMount(newWeapon));
        }
    }

    // Button 1: Equip Scepter Cannon
    hud.button("Scepter Gun", () => {
        attachWeapon("scepter", 0);
    }).width(130).height(40).pad(2).row();

    // Button 2: Equip Corvus Laser
    hud.button("Corvus Laser", () => {
        attachWeapon("corvus", 0);
    }).width(130).height(40).pad(2).row();

    // Button 3: Equip Reign Heavy Cannon
    hud.button("Reign Cannon", () => {
        attachWeapon("reign", 0);
    }).width(130).height(40).pad(2).row();

    // Button 4: Clear All Weapons
    hud.button("Clear Weapons", () => {
        let unit = Vars.player.unit();
        if (unit) unit.mounts.clear();
    }).width(130).height(40).pad(2).color(Color.scarlet).row();

    // Add HUD element directly to UI layer
    Vars.ui.hudGroup.addChild(hud);
});
